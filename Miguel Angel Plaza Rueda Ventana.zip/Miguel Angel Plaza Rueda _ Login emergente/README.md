# Proyecto: Plantilla03

## Descripción
En este proyecto utilizamos la plantilla 3 para introducir un login con ventana emergente mediante defer.

## Estructura del Proyecto
- `login.js`: Archivo que contiene una ventana emergente que al poner jota (usuario) y dejame (contraseña) deja acceder a los ejercicios.
- `index.html`: Archivo principal que contiene la estructura básica de la página web.

## Cómo Usar
1. Clona el repositorio en tu máquina local.
2. Abre el archivo `index.html` en tu navegador preferido para ver la plantilla.
3. Modifica el archivo según tus necesidades para desarrollar tu página web.

## Tecnologías Utilizadas
- HTML5

## Autor
Miguel Angel Plaza Rueda

