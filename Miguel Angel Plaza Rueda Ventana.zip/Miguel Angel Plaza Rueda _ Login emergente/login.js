window.onload = function() {
  login();
};

function login() {
  // Solicitar nombre de usuario
  let username = prompt("Por favor, ingrese su nombre de usuario:");

  // Verificar si el usuario canceló el prompt
  if (username === null) {
    alert("Acceso cancelado.");
    return;
  }

  // Validar que el usuario tenga al menos 3 caracteres
  if (username.length < 3) {
    alert("El nombre de usuario debe tener al menos 3 caracteres.");
    login(); // Reiniciar login
    return;
  }

  // Solicitar contraseña
  let password = prompt("Por favor, ingrese su contraseña:");

  // Verificar si el usuario canceló el prompt
  if (password === null) {
    alert("Acceso cancelado.");
    return;
  }

  // Validar credenciales
  if (username === "jota" && password === "dejame") {
    // Credenciales correctas
    alert("¡Bienvenido!");
    document.getElementById("mainContent").style.display = "block"; // Mostrar el contenido principal
  } else {
    // Credenciales incorrectas
    let tryAgain = confirm("Credenciales incorrectas. ¿Desea intentarlo de nuevo?");
    if (tryAgain) {
      login(); // Reiniciar login
    } else {
      alert("Acceso denegado.");
    }
  }
}
