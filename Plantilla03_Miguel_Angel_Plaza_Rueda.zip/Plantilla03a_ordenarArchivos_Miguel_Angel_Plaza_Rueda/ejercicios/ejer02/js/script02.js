

"use strict";

document.getElementById("boton").addEventListener("click", () => mostrar(document.getElementById("resultado")));
